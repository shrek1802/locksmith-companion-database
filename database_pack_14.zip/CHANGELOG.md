# Database Changelog

## 2026.07.04-big-psa-opel-individual-1
- PSA/Opel individual expansion: 60 records.
- Adds Peugeot, Citroen, DS and Vauxhall generation-level records.