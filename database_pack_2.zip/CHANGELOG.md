# Database Changelog

## 2026.07.04-multipack-fca-commercial-1
- Fiat, Alfa, MG and Iveco v5 coverage refresh.
- Uses SIP22/FCA families where high confidence.
- MG EV/newer smart key records marked needs_review.