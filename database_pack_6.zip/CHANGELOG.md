# Database Changelog

## 2026.07.04-multipack-korean-utility-1
- Hyundai/Kia/KGM/Isuzu coverage expansion.
- Adds broader model-family records.
- KGM and Isuzu kept needs_review until direct confirmation.