# Database Changelog

## 2026.07.04-multipack-asian-2
- Toyota/Lexus/Honda/Subaru coverage expansion.
- Adds broader model-family records for common UK Asian vehicles.
- Exact newest smart systems marked needs_review where needed.