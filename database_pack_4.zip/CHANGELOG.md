# Database Changelog

## 2026.07.04-multipack-alliance-2
- Renault/Nissan/Mitsubishi Alliance coverage expansion.
- Adds larger model-family records for common UK cars and commercials.
- Newer EV/smart systems remain needs_review where exact workshop confirmation is needed.