# Database Changelog

## 2026.07.04-big-vag-individual-1
- VAG individual expansion: 44 records.
- Adds generation-level VW, Audi, Skoda and SEAT/Cupra records.