# Database Changelog

## 2026.07.04-multipack-bmw-mini-mercedes-1
- BMW, MINI and Mercedes v5 coverage refresh.
- Groups by CAS/FEM/BDC and FBS families.
- Exact newer smart key systems marked high_confidence/needs_review.