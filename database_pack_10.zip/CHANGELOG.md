# Database Changelog

## 2026.07.04-multipack-legacy-rare-1
- Legacy/rare UK vehicle coverage pack.
- Adds Chevrolet, Chrysler, Dodge, Saab, Rover and legacy MG family records.
- Most legacy/rare records are needs_review until stronger confirmation.