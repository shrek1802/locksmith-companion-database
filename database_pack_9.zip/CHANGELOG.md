# Database Changelog

## 2026.07.04-multipack-psa-stellantis-exp-1
- PSA/Stellantis expansion pack.
- Adds family-level coverage for Peugeot, Citroen, Vauxhall and Fiat Professional.
- Separates older GM/PSA/Toyota/Renault-shared systems by notes and platform.