# Database Changelog

## 2026.07.04-multipack-luxury-1
- Luxury/supercar coverage pack.
- Adds Rolls-Royce, Aston Martin, Ferrari, Maserati and Lamborghini family records.
- All records kept needs_review until exact key systems are confirmed.