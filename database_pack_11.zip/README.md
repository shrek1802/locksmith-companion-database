# 2026.07.04-multipack-luxury-1

Upload with the other database_pack*.zip files and run Install Database Packs.
