# Database Changelog

## 2026.07.04-big-ford-individual-1
- Ford individual generation/key-system expansion: 47 records.
- Replaces broad Ford family entries with more granular vehicle records.