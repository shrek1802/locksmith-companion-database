# Database Changelog

## 2026.07.04-multipack-ford-mazda-exp-1
- Ford and Mazda expansion pack.
- Adds broader model-family coverage for cars and commercials.
- Newest shared Ford/VW platforms and Mazda smart systems kept high_confidence or needs_review.