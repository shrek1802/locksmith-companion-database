# Database Changelog

## 2026.07.04-big-bmw-individual-1
- BMW generation/key-system expansion: 66 records.
- Splits BMW by E/F/G chassis and EWS/CAS/CAS4/FEM/BDC family.