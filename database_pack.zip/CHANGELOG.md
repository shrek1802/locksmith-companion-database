# Database Changelog

## 2026.07.04-multipack-vag-1
- VAG v5 coverage refresh.
- Updates VW, Audi, Skoda and SEAT/Cupra.
- Uncertain MQB/MQB Evo variants marked high_confidence or needs_review.